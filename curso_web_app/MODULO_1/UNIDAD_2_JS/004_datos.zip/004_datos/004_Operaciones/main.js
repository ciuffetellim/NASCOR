let num1 = parseInt(prompt("Introduce un número"));
document.write('Primer numero: ' + num1);

let num2 = parseInt(prompt("Introduce otro número"));
document.write('<br>Segundo número: ' + num2);

let suma = num1 + num2;
document.write('<br><b><i><span id="textos">Suma: ' + suma + '</span> ');